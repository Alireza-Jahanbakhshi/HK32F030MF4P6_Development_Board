#ifndef __INTERNAL_FLASH_H
#define __INTERNAL_FLASH_H

#include "hk32f030m.h"

#define FLASH_PAGE_SIZE   ((uint16_t)0x80)

// д�����ʼ��ַ�������ַ
#define WRITE_START_ADDR   ((uint32_t)0x08002000)
#define WRITE_END_ADDR     ((uint32_t)0x08002400)

typedef enum
{
  FAILED = 0,
  PASSED = !FAILED
}TestStatus;


int InternalFlash_Test1(void);
int InternalFlash_Test2(void);

#endif /* __INTERNAL_FLASH_H */


