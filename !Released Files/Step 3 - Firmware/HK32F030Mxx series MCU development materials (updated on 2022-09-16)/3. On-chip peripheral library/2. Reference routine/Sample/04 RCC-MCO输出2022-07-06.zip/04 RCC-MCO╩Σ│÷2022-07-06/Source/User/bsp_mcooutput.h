#ifndef __MCOOUTPUT_H
#define	__MCOOUTPUT_H


#include "hk32f030m.h"

void MCO_GPIO_Config(void);


#endif /* __MCOOUTPUT */
















