#ifndef __BSP_I2C_EE_H
#define __BSP_I2C_EE_H

#include "hk32f030m.h"

#define sEE_OK                    0
#define sEE_FAIL                  1   

#define EEPROM_DEV_ADDR        0xA0
#define EEPROM_WR              0x00
#define EEPROM_RD              0x01
#define EEPROM_WORD_ADDR_SIZE  0x08

#define EEPROM_PAGE_SIZE       8
//#define EEPROM_PAGE_SIZE       16


int8_t EEPROM_WriteByte(uint16_t Addr, uint8_t byteData);
int8_t EEPROM_ReadByte(uint8_t Addr, uint8_t *byteData);
uint32_t sEE_ReadBuffer(uint8_t* pBuffer, uint16_t ReadAddr, uint16_t* NumByteToRead);
uint32_t sEE_WritePage(uint8_t* pBuffer, uint16_t WriteAddr, uint8_t* NumByteToWrite);
void sEE_WriteBuffer(uint8_t* pBuffer, uint16_t WriteAddr, uint16_t NumByteToWrite);

#endif



























