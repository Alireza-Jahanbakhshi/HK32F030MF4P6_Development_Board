/**
  ******************************************************************************
  * @file    bsp_i2c_ee.c
  * @author  STMicroelectronics
  * @version V1.0
  * @date    2022-xx-xx
  * @brief   i2c EEPROM(AT24C02)Ӧ�ú���bsp
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:HK32F030M������ 
  * ��̳    :https://bbs.21ic.com/iclist-1010-1.html
  *
  ******************************************************************************
  */ 

#include "bsp_i2c_ee.h"
#include "bsp_i2c_gpio.h"

uint16_t  sEEDataNum;

int8_t  EEPROM_WriteByte(uint16_t Addr, uint8_t dataValue)
{
  Sf_I2C_Start();
  
  Sf_I2C_SendOneByte(EEPROM_DEV_ADDR | EEPROM_WR);  // send device address
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                 // receive ack failed
  }
  
  #if (0x08 == EEPROM_WORD_ADDR_SIZE)         // send eeprom memory address
  Sf_I2C_SendOneByte((uint8_t)(Addr&0x00FF));
  #else
  I2C_SendOneByte((uint8_t)(Addr>>8));
  I2C_SendOneByte((uint8_t)(Addr&0x00FF));
  #endif
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                 // receive ack failed
  }
  
  Sf_I2C_SendOneByte(dataValue);
  Sf_I2C_Stop();
  return sEE_OK;                                  // write to eeprom successful
}


int8_t EEPROM_ReadByte(uint8_t Addr, uint8_t *byteData)
{
  Sf_I2C_Start();
  
  Sf_I2C_SendOneByte(EEPROM_DEV_ADDR | EEPROM_WR);   // send device address
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)
  {
    Sf_I2C_Stop();
    return sEE_FAIL;
  }
  
  #if (0x08 == EEPROM_WORD_ADDR_SIZE)          // send memory address
  Sf_I2C_SendOneByte((uint8_t)(Addr&0x00FF));
  #else
  I2C_SendOneByte((uint8_t)(Addr>>8));
  I2C_SendOneByte((uint8_t)(Addr&0x00FF));
  #endif
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  }
  
  Sf_I2C_Start();
  
  Sf_I2C_SendOneByte(EEPROM_DEV_ADDR | EEPROM_RD);  // send deceive address again
  
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  }

  *byteData = Sf_I2C_ReceiveOneByte(0);
  Sf_I2C_Stop();
  return sEE_OK;                                   // read for eeprom successful
}

/*AT24C02 device address
   ----------------------------------------------
  |  1K/2K  | 1 | 0 | 1 | 0 | A2 | A1 | A0 | R/W |  
  |          MSB                       LSB       |
   ----------------------------------------------
  |  4K     | 1 | 0 | 1 | 0 | A2 | A1 | P0 | R/W |
  -----------------------------------------------
  |  4K     | 1 | 0 | 1 | 0 | A2 | P1 | P0 | R/W |
   ----------------------------------------------
  |  4K     | 1 | 0 | 1 | 0 | P2 | P1 | P0 | R/W |
   ----------------------------------------------

  Memory organization
  AT24C01,1K -- Internally organized with 16 pages of 8 bytes each, 
        the 1K requires a 7-bit data word address for random word addressing.
  AT24C02,2K -- Internally organized with 32 pages of 8 bytes each, 
        the 2K requires a 7-bit data word address for random word addressing.
  AT24C04,4K -- Internally organized with 32 pages of 16 bytes each, 
        the 4K requires a 7-bit data word address for random word addressing.
  AT24C08,8K -- Internally organized with 64 pages of 16 bytes each, 
        the 8K requires a 7-bit data word address for random word addressing.
  AT24C16,16K -- Internally organized with 128 pages of 16 bytes each, 
        the 16K requires a 7-bit data word address for random word addressing.
*/

/**
  * @brief  Reads a block of data from the EEPROM.
  * @param  pBuffer: pointer to the buffer that receives the data read from 
  *         the EEPROM.
  * @param  ReadAddr: EEPROM's internal address to start reading from.
  * @param  NumByteToRead: pointer to the variable holding number of bytes to 
  *         be read from the EEPROM.
  *
  * @retval sEE_OK 1 if operation is correctly performed, else return value 
  *         different from 0 or the timeout user callback.
  */
uint32_t sEE_ReadBuffer(uint8_t* pBuffer, uint16_t ReadAddr, uint16_t* NumByteToRead)
{  
  uint32_t NumbOfSingle = 0, Count = 0, DataNum = 0;
  
  /* Get number of reload cycles */
  Count = (*NumByteToRead) / 255;  
  NumbOfSingle = (*NumByteToRead) % 255;
  
  /* Configure slave address, nbytes, reload and generate start */
  Sf_I2C_Start();  
  Sf_I2C_SendOneByte((EEPROM_DEV_ADDR | EEPROM_WR)+((ReadAddr/256)<<1));   
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  }
  Sf_I2C_SendOneByte(ReadAddr%256);   
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  }  
  Sf_I2C_Start();  	 	   
  Sf_I2C_SendOneByte(EEPROM_DEV_ADDR | EEPROM_RD);           	   
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  } 
  
  /* If number of Reload cycles is not equal to 0 */
  while (Count != 0)
  {
      /* Update local variable */     
      DataNum = 0;
    
      /* Wait until all data are received */
      while(DataNum != 255)
      {        
          /* Read data from RXDR */
          pBuffer[DataNum]= Sf_I2C_ReceiveOneByte(1);
      
          /* Update number of received data */
          DataNum++;
          (*NumByteToRead)--;
      }      
      /* Update Pointer of received buffer */ 
      pBuffer += DataNum;  
    
      /* update number of reload cycle */
      Count--;
  }
    
  /* If number of single data is not equal to 0 */
  if (NumbOfSingle != 0)
  {            
      /* Reset local variable */
      DataNum = 0;
    
      /* Wait until all data are received */
      while (DataNum != NumbOfSingle)
      {        
          /* Read data from RXDR */
          pBuffer[DataNum]= Sf_I2C_ReceiveOneByte(1);
      
          /* Update number of received data */
          DataNum++;
          (*NumByteToRead)--;
      } 
  }
  else
  {   
      /* Reset local variable */
      DataNum = 0;
      
      /* Wait until all data are received */
      while (DataNum != NumbOfSingle)
      {
        
        /* Read data from RXDR */
        pBuffer[DataNum]= Sf_I2C_ReceiveOneByte(1);
        
        /* Update number of received data */
        DataNum++;
        (*NumByteToRead)--;
      }    
  }
  Sf_I2C_Nack();
  Sf_I2C_Stop();//����һ��ֹͣ����	
  /* If all operations OK, return sEE_OK (0) */
  return sEE_OK;
}

/**
  * @brief  Writes more than one byte to the EEPROM with a single WRITE cycle.
  *
  * @note   The number of bytes (combined to write start address) must not 
  *         cross the EEPROM page boundary. This function can only write into
  *         the boundaries of an EEPROM page.
  * @note   This function doesn't check on boundaries condition (in this driver 
  *         the function sEE_WriteBuffer() which calls sEE_WritePage() is 
  *         responsible of checking on Page boundaries).
  * 
  * @param  pBuffer: pointer to the buffer containing the data to be written to 
  *         the EEPROM.
  * @param  WriteAddr: EEPROM's internal address to write to.
  * @param  NumByteToWrite: pointer to the variable holding number of bytes to 
  *         be written into the EEPROM.
  *
  * @retval sEE_OK (0) if operation is correctly performed, else return value 
  *         different from sEE_OK (0) or the timeout user callback.
  */
uint32_t sEE_WritePage(uint8_t* pBuffer, uint16_t WriteAddr, uint8_t* NumByteToWrite)
{   
  uint32_t DataNum = 0;
  
  /* Configure slave address, nbytes, reload and generate start */
  Sf_I2C_Start();
  
  /* Send memory address */
  Sf_I2C_SendOneByte(0XA0+((WriteAddr/256)<<1));   //����������ַ0XA0,д���� 
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  } 
  Sf_I2C_SendOneByte(WriteAddr%256);   //���͵͵�ַ
  if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
  {
    Sf_I2C_Stop();
    return sEE_FAIL;                                  // receive ack failed
  } 	 										  		   
  
  while (DataNum != (*NumByteToWrite))
  {      
    Sf_I2C_SendOneByte((uint8_t)(pBuffer[DataNum]));     //�����ֽ�
    if(Sf_I2C_GetAck() != Sf_I2C_ACK_OK)                           
    {
      Sf_I2C_Stop();
      return 0;                                  // receive ack failed
    } 
    /* Update number of transmitted data */
    DataNum++;   
  } 
    
  Sf_I2C_Stop();
  // delay abaout 1ms after one page written
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);  Sf_I2C_Delay(255);Sf_I2C_Delay(255);
  
  /* If all operations OK, return sEE_OK (1) */
  return sEE_OK;
}

/**
  * @brief  Writes buffer of data to the I2C EEPROM.
  * @param  pBuffer: pointer to the buffer  containing the data to be written 
  *         to the EEPROM.
  * @param  WriteAddr: EEPROM's internal address to write to.
  * @param  NumByteToWrite: number of bytes to write to the EEPROM.
  * @retval None
  */
void sEE_WriteBuffer(uint8_t* pBuffer, uint16_t WriteAddr, uint16_t NumByteToWrite)
{
  uint16_t NumOfPage = 0, NumOfSingle = 0, count = 0;
  uint16_t Addr = 0;
  
  Addr = WriteAddr % EEPROM_PAGE_SIZE;
  count = EEPROM_PAGE_SIZE - Addr;
  NumOfPage =  NumByteToWrite / EEPROM_PAGE_SIZE;
  NumOfSingle = NumByteToWrite % EEPROM_PAGE_SIZE;
  
  /* If WriteAddr is sEE_PAGESIZE aligned  */
  if(Addr == 0) 
  {
    /* If NumByteToWrite < sEE_PAGESIZE */
    if(NumOfPage == 0) 
    {
      /* Store the number of data to be written */
      sEEDataNum = NumOfSingle;
      sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum));
    }
    /* If NumByteToWrite > sEE_PAGESIZE */
    else  
    {
      while(NumOfPage--)
      {
        /* Store the number of data to be written */
        sEEDataNum = EEPROM_PAGE_SIZE;        
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum)); 
        WriteAddr +=  EEPROM_PAGE_SIZE;
        pBuffer += EEPROM_PAGE_SIZE;
      }
      
      if(NumOfSingle!=0)
      {
        /* Store the number of data to be written */
        sEEDataNum = NumOfSingle;          
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum));
      }
    }
  }
  /* If WriteAddr is not sEE_PAGESIZE aligned  */
  else 
  {
    /* If NumByteToWrite < sEE_PAGESIZE */
    if(NumOfPage== 0) 
    {
      /* If the number of data to be written is more than the remaining space 
      in the current page: */
      if (NumByteToWrite > count)
      {
        /* Store the number of data to be written */
        sEEDataNum = count;        
        /* Write the data contained in same page */
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum));    
        
        /* Store the number of data to be written */
        sEEDataNum = (NumByteToWrite - count);          
        /* Write the remaining data in the following page */
        sEE_WritePage((uint8_t*)(pBuffer + count), (WriteAddr + count), (uint8_t*)(&sEEDataNum));      
      }      
      else      
      {
        /* Store the number of data to be written */
        sEEDataNum = NumOfSingle;         
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum));      
      }     
    }
    /* If NumByteToWrite > sEE_PAGESIZE */
    else
    {
      NumByteToWrite -= count;
      NumOfPage =  NumByteToWrite / EEPROM_PAGE_SIZE;
      NumOfSingle = NumByteToWrite % EEPROM_PAGE_SIZE;
      
      if(count != 0)
      {  
        /* Store the number of data to be written */
        sEEDataNum = count;         
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum));
        WriteAddr += count;
        pBuffer += count;
      } 
      
      while(NumOfPage--)
      {
        /* Store the number of data to be written */
        sEEDataNum = EEPROM_PAGE_SIZE;          
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum));
        WriteAddr +=  EEPROM_PAGE_SIZE;
        pBuffer += EEPROM_PAGE_SIZE;  
      }
      if(NumOfSingle != 0)
      {
        /* Store the number of data to be written */
        sEEDataNum = NumOfSingle;           
        sEE_WritePage(pBuffer, WriteAddr, (uint8_t*)(&sEEDataNum)); 
      }
    }
  }  
}

/*
 * eeprom AT24C02 ��д����
 * ��������1, �쳣����0
*/
uint8_t EEPROM_Test(void)
{
  uint16_t i;
	uint8_t write_buf[EEPROM_SIZE];
  uint8_t read_buf[EEPROM_SIZE];
  uint16_t NumToRead = 0;

/*------------------------------------------------------------------------------------*/  
  /* �����Ի����� */
	for (i = 0; i < EEPROM_SIZE; i++)
	{		
		write_buf[i] = i;
	}
/*------------------------------------------------------------------------------------*/  
  printf("дeeprom\r\n");
  sEE_WriteBuffer(write_buf, 0, EEPROM_SIZE);
	
/*-----------------------------------------------------------------------------------*/
  if (sEE_ReadBuffer(read_buf, 0, &NumToRead) != sEE_OK)
	{
		printf("��eeprom������\r\n");
		return 0;
	}
	else
	{		
		printf("��eeprom�ɹ����������£�\r\n");
	}
/*-----------------------------------------------------------------------------------*/  
  for (i = 0; i < EEPROM_SIZE; i++)
	{
		if(read_buf[i] != write_buf[i])
		{
			printf("0x%02X ", read_buf[i]);
			printf("����:EEPROM������д������ݲ�һ��");
			return 0;
		}
    printf(" %02X", read_buf[i]);
		
		if ((i & 15) == 15)
		{
			printf("\r\n");	
		}		
	}
  printf("eeprom��д���Գɹ�\r\n");
  return 1;  
}











