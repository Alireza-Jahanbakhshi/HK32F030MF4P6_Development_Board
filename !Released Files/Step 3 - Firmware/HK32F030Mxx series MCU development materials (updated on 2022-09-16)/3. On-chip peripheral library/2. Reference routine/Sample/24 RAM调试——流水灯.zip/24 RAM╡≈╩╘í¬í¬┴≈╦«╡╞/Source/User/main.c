/**
  ******************************************************************************
  * @file    main.c
  * @author  Alexander
  * @version V1.0
  * @date    2022-xx-xx
  * @brief   ��RAM���ԡ�����ˮ��
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:HK32F030M������ 
  * ��̳    :https://bbs.21ic.com/iclist-1010-1.html
  *
  ******************************************************************************
  */ 
#include "hk32f030m.h" 
#include "bsp_led.h"

#define SOFT_DELAY  Delay(0x0FFFFF);

void Delay(__IO uint32_t nCount); 

/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
 
int main(void)
{
	/* LED �˿ڳ�ʼ�� */
	LED_GPIO_Config();	
  
  while (1)
	{
    /* �������IO�ĺ� */
		LED1_ON;			  // ��
		SOFT_DELAY;
		LED1_OFF;		   // ��

		LED2_ON;			 // ��
		SOFT_DELAY;
		LED2_OFF;		   // ��

		LED3_ON;			 // ��
		SOFT_DELAY;
		LED3_OFF;		   // ��    
	}
}

void Delay(__IO uint32_t nCount)	 //�򵥵���ʱ����
{
	for(; nCount != 0; nCount--);
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char* file , uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */	
       /* Infinite loop */
	
	while (1)
  {		
  }
}
#endif /* USE_FULL_ASSERT */


