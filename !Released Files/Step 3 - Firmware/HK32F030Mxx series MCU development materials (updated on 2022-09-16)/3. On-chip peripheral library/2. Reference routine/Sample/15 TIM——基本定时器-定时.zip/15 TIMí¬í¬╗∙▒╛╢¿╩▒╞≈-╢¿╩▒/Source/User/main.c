/**
  ******************************************************************************
  * @file    main.c
  * @author  Alexander
  * @version V1.0
  * @date    2022-xx-xx
  * @brief   ������ʱ��
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:HK32F030M������ 
  * ��̳    :https://bbs.21ic.com/iclist-1010-1.html
  *
  ******************************************************************************
  */ 
#include "hk32f030m.h" 
#include "bsp_led.h"
#include "bsp_TimBase.h"

volatile uint32_t time = 0;  // ms ��ʱ����


/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
 
int main(void)
{
	/* LED �˿ڳ�ʼ�� */
	LED_GPIO_Config();	
  
  BASIC_TIM_Init();
  
  while (1)
	{
    if( time == 1000 )  /* 1000 * 1ms = 1s ʱ�䵽 */
    {
      time = 0;
      /* LED1 ȡ�� */
      LED1_TOGGLE;
    }
    
	}
}


#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(char* file , uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */	
       /* Infinite loop */
	
	while (1)
  {		
  }
}
#endif /* USE_FULL_ASSERT */


