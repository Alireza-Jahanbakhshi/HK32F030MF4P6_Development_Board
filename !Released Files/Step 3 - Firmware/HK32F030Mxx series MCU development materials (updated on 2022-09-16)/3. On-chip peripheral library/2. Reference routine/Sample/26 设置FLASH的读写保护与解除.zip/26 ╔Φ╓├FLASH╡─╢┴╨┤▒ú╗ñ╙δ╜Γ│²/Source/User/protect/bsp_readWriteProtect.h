#ifndef __INTERNAL_FLASH_H
#define	__INTERNAL_FLASH_H

#include "hk32f030m.h"

#define FLASH_PAGE_SIZE    ((uint16_t)0x80)	//128 Bytes

//д�����ʼ��ַ�������ַ
#define WRITE_START_ADDR  ((uint32_t)0x08008000)
#define WRITE_END_ADDR    ((uint32_t)0x0800C000)



typedef enum 
{
	WRITE_PROTECTED = 0, 
  NO_WRITE_PROTECT 
} Protect_Status;




/*********************************************/
/*��Ϣ���*/
#define FLASH_DEBUG_ON                   1

#define FLASH_INFO(fmt,arg...)           printf("<<-FLASH-INFO->> "fmt"\n",##arg)
#define FLASH_ERROR(fmt,arg...)          printf("<<-FLASH-ERROR->> "fmt"\n",##arg)
#define FLASH_DEBUG(fmt,arg...)          do{\
                                          if(FLASH_DEBUG_ON)\
                                          printf("<<-FLASH-DEBUG->> [%d]"fmt"\n",__LINE__, ##arg);\
                                          }while(0)

void WriteProtect_Toggle(void);																				
void ReadProtect_Toggle(void);

#endif /* __INTERNAL_FLASH_H */

