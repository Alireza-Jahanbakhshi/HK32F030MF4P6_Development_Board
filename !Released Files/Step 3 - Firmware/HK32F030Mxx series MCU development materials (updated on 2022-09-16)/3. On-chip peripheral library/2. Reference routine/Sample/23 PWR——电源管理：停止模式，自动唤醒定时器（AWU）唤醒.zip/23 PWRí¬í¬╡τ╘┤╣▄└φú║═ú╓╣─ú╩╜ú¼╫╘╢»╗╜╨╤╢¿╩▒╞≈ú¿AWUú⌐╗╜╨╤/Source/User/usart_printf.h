#ifndef __USART_PRINTF_H
#define __USART_PRINTF_H
#include "hk32f030m.h"

void Usart1_Printf_Init(uint32_t baudrate);


#endif

