#ifndef __BSP_ADVANCETIME_H
#define __BSP_ADVANCETIME_H


#include "hk32f030m.h"


/********************�߼���ʱ��TIM�������壬ֻ��TIM1***************/
#define            ADVANCE_TIM                   TIM1
#define            ADVANCE_TIM_APBxClock_FUN     RCC_APB2PeriphClockCmd
#define            ADVANCE_TIM_CLK               RCC_APB2Periph_TIM1
#define            ADVANCE_TIM_Period            (1000-1)
#define            ADVANCE_TIM_Prescaler         31
#define            ADVANCE_TIM_IRQ               TIM1_UP_TRG_COM_IRQn
#define            ADVANCE_TIM_IRQHandler        TIM1_UP_TRG_COM_IRQHandler
/**************************��������********************************/

void ADVANCE_TIM_Init(void);


#endif	/* __BSP_ADVANCETIME_H */


