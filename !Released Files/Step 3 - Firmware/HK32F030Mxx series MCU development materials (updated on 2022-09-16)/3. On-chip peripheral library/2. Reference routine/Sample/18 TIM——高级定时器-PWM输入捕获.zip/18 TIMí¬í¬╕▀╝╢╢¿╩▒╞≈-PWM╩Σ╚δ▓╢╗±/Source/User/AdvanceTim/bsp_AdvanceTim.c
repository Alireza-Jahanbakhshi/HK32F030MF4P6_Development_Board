#include "bsp_AdvanceTim.h" 

static void ADVANCE_TIM_GPIO_Config(void) 
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  // ����Ƚ�ͨ��GPIO��ʼ��
  RCC_AHBPeriphClockCmd(ADVANCE_TIM_CH1_GPIO_CLK, ENABLE);
  
  // ����GPIO�ĸ��ù���
  GPIO_PinAFConfig(ADVANCE_TIM_CH2_PORT, ADVANCE_TIM_CH2_PinSource, ADVANCE_TIM_CH2_GPIO_AF);
  
  GPIO_InitStructure.GPIO_Pin = ADVANCE_TIM_CH2_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_InitStructure.GPIO_Schmit = GPIO_Schmit_Disable;
  // ��ʼ��IO����
  GPIO_Init(ADVANCE_TIM_CH2_PORT, &GPIO_InitStructure);
  
}


static void ADVANCE_TIM_Mode_Config(void)
{
  TIM_ICInitTypeDef TIM_ICInitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;
  
  // ������ʱ��ʱ��,���ڲ�ʱ��CK_INT=32M
	ADVANCE_TIM_APBxClock_FUN(ADVANCE_TIM_CLK,ENABLE);
  
  // ����TIM1 CH2
  TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
  TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
  TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
  TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
  TIM_ICInitStructure.TIM_ICFilter = 0x0;
  
  // ʹ��TIM1����Ƚ��ж�
  NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
  TIM_PWMIConfig(TIM1, &TIM_ICInitStructure);
  
  // ѡ��TIM1���봥����TI2FP2
  TIM_SelectInputTrigger(TIM1,TIM_TS_TI2FP2);
  
  // ��ģʽ��λ������
  TIM_SelectSlaveMode(TIM1, TIM_SlaveMode_Reset);
  
  // ʹ������ģʽ
  TIM_SelectMasterSlaveMode(TIM1, TIM_MasterSlaveMode_Enable);
  
  // ʹ��TIM1
  TIM_Cmd(TIM1, ENABLE);
  
  // ʹ��TIM1����Ƚ�2�ж�
  TIM_ITConfig(TIM1, TIM_IT_CC2, ENABLE);
}

void ADVANCE_TIM_Init(void)
{
	ADVANCE_TIM_GPIO_Config();
	ADVANCE_TIM_Mode_Config();		
}

/*********************************************END OF FILE**********************/
